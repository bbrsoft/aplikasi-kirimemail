<?php
// Data Header
$username = "Embuilders123";
$token = "9xd2LXB3HgUotpeGuFrVKnOTCJszMvY7Embuilders123";
$timestamp = time(); // Timestamp saat ini

// Generate Auth-Token
$toHash = "$username::$token::$timestamp";
$generatedToken = hash_hmac('sha256', $toHash, $token);

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://api.kirim.email/v3/subscriber/',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => 'lists=397521&full_name=Marta&email=marataantonio795@gmail.com&fields%5Bno_hp%5D=%2B628123456789&fields%5Balamat%5D=Indonesia&tags=new%20tag%2C%20test%20tag',
  CURLOPT_HTTPHEADER => array(
    "Auth-Id: $username",
    "Auth-Token: $generatedToken",
    "Timestamp: $timestamp",
    "Content-Type: application/x-www-form-urlencoded"
  ),
));

$response = curl_exec($curl);

curl_close($curl);
echo $response;

?>

<?php
$username = "Embuilders123";
$token = "9xd2LXB3HgUotpeGuFrVKnOTCJszMvY7Embuilders123";
$timestamp = time(); // Timestamp saat ini

// Generate Auth-Token
$toHash = "$username::$token::$timestamp";
$generatedToken = hash_hmac('sha256', $toHash, $token);

// Format Bearer Token
$bearerToken = "Bearer " . $generatedToken;

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://api.kirim.email/v3/list',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
  CURLOPT_HTTPHEADER => array(
    "Auth-Id: $username",
    "Auth-Token: $generatedToken",
    "Timestamp: $timestamp",
    "Authorization: $bearerToken", // Bearer token ditambahkan di sini
  ),
));

$response = curl_exec($curl);

$httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE); // Ambil status HTTP
$error = curl_error($curl);

curl_close($curl);

// Debugging Output
if ($httpCode !== 200) {
    echo "HTTP Code: $httpCode\n";
    echo "CURL Error: $error\n";
    echo "Response: $response\n";
} else {
    echo $response;
}

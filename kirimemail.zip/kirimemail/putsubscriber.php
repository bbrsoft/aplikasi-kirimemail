<?php
// Data Header
$username = "Embuilders123";
$token = "Yo3SC1rRnvF2X4Z8Blh5cKjaAwMsdi0LEmbuilders123";
$timestamp = time(); // Timestamp saat ini

// Generate Auth-Token
$toHash = "$username::$token::$timestamp";
$generatedToken = hash_hmac('sha256', $toHash, $token);

// Email subscriber
$emailSubscriber = "marataantonio795@gmail.com";

// Data Body
$body = [
    'tags' => 'new tag',
];

// Header
$headers = [
    "Auth-Id: $username",
    "Auth-Token: $generatedToken",
    "Timestamp: $timestamp",
    "Content-Type: application/x-www-form-urlencoded",
];

// Endpoint URL
$url = "https://api.kirim.email/v3/subscriber/email/" . urlencode($emailSubscriber);

// Konversi body menjadi string x-www-form-urlencoded
$bodyString = http_build_query($body, '', '&', PHP_QUERY_RFC1738);

// Kirim cURL Request dengan PUT
$curl = curl_init($url);
curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
curl_setopt($curl, CURLOPT_POSTFIELDS, $bodyString);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

// Eksekusi dan tangkap respons
$response = curl_exec($curl);
$httpcode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
curl_close($curl);

// Cek hasil
if ($httpcode === 200) {
    echo "Subscriber berhasil diperbarui:\n$response\n";
} else {
    echo "Error: $httpcode\n$response\n";
}
?>

<?php
// Data Header
$username = "Embuilders123";
$token = "9xd2LXB3HgUotpeGuFrVKnOTCJszMvY7Embuilders123";
$timestamp = time(); // Timestamp saat ini

// Generate Auth-Token
$toHash = "$username::$token::$timestamp";
$generatedToken = hash_hmac('sha256', $toHash, $token);

// Data Body
$body = [
    'title' => 'Your Title',
    'sender' => 'embuilders123@buletin.co',
    'messages' => [
        [
            'subject' => 'Your Subject',
            'content' => '<body>Your HTML Content</body>',
        ]
    ],
    'send_at' => date('Y-m-d H:i:s'), // Format tanggal yang benar
    'list' => 1,
];

// Header
$headers = [
    "Auth-Id: $username",
    "Auth-Token: $generatedToken",
    "Timestamp: $timestamp",
    "Content-Type: application/json",
];

// Kirim cURL Request
$curl = curl_init("https://api.kirim.email/v3/broadcast/");
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($body));
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

// Eksekusi dan tangkap respons
$response = curl_exec($curl);
$httpcode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
curl_close($curl);

// Cek hasil
if ($httpcode === 200) {
    echo "Broadcast berhasil dikirim:\n$response\n";
} else {
    echo "Error: $httpcode\n$response\n";
}
?>

<?php

// Konfigurasi API
$apiUrl = 'https://aplikasi.kirim.email/api/v3/transactional/messages';
$apiKey = 'de01a87fec6b2c87a1d2d2ea529a1f0e1bee9b84aee98da8ceedfe19e8cb71a2';
$domain = 'app.supertim.id';
$fromEmail = 'noreply@app.supertim.id';
$toEmail = 'bbrsoftdream@gmail.com';

// Data POST
$post = array(
    'from' => $fromEmail,
    'to' => $toEmail,
    'subject' => 'Hello',
    'text' => 'Testing'
);

// Inisialisasi cURL
$curl = curl_init();
curl_setopt_array($curl, array(
    CURLOPT_URL => $apiUrl,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_USERPWD => 'api' . ':' . $apiKey,
    CURLOPT_POSTFIELDS => http_build_query($post),
    CURLOPT_HTTPHEADER => array(
        'Domain: ' . $domain
    ),
));

// Eksekusi permintaan
$response = curl_exec($curl);

// Periksa kesalahan
if (curl_errno($curl)) {
    echo 'cURL Error: ' . curl_error($curl);
} else {
    echo 'Response: ' . $response;
}

// Tutup koneksi
curl_close($curl);

?>

<?php
// Data yang dibutuhkan
$username = "Embuilders123";
$token = "9xd2LXB3HgUotpeGuFrVKnOTCJszMvY7Embuilders123";
$timestamp = time(); // Timestamp saat ini
$guid = '3eb3f143-739d-4b14-916e-9d8bcebe3a72';
// Buat string untuk di-hash
$toHash = "$username::$token::$timestamp";
echo "String to Hash: $toHash\n";

// Hasilkan HMAC SHA256
$generatedToken = hash_hmac('sha256', $toHash, $token);
echo "Generated Token: $generatedToken\n";

// Siapkan Header untuk Permintaan
$headers = [
    "Auth-Id: $username",
    "Auth-Token: $generatedToken",
    "Timestamp: $timestamp",
];

// Kirim cURL Request
$curl = curl_init("https://api.kirim.email/v3/broadcast/".$guid);
curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

// Eksekusi dan tangkap respons
$response = curl_exec($curl);
curl_close($curl);

echo "Response: $response\n";
?>

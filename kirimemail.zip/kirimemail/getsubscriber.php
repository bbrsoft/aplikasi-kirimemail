<?php
// Data Header
$username = "Embuilders123";
$token = "9xd2LXB3HgUotpeGuFrVKnOTCJszMvY7Embuilders123";
$timestamp = time(); // Timestamp saat ini

// Generate Auth-Token
$toHash = "$username::$token::$timestamp";
$generatedToken = hash_hmac('sha256', $toHash, $token);

// Header
$headers = [
    "Auth-Id: $username",
    "Auth-Token: $generatedToken",
    "Timestamp: $timestamp"
];

// Log untuk debugging
echo "Headers:\n" . print_r($headers, true) . "\n";

// Kirim cURL Request
$curl = curl_init("https://api.kirim.email/v3/subscriber/"); // Pastikan URL endpoint benar
curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

// Eksekusi dan tangkap respons
$response = curl_exec($curl);
$httpcode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
curl_close($curl);

// Cek hasil
if ($httpcode === 200) {
    echo "Data subscriber berhasil diambil:\n$response\n";
} else {
    echo "Error: $httpcode\n$response\n";
}
?>
